package com.yash.demo;

import java.util.ArrayList;
import java.util.List;


public class Feed {



    final List<FeedMessage> entries = new ArrayList<FeedMessage>();



    public List<FeedMessage> getMessages() {
        return entries;
    }





}